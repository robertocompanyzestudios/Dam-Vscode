import java.util.Scanner;

/*Roberto Company Zomeño
*
*
*
*
*/



public class ejercicio1{
	public static void main(String[] args){
		Scanner teclado = new Scanner(System.in);



	}
}