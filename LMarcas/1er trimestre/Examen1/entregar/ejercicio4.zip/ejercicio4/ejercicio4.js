function accion(){
    let n = document.getElementById("numeros").value

    let lista = document.getElementById("lista")

    let listaOl = document.createElement("ol")

    for(i=0; i < n; i++){
        let listaOl_entrada = document.createElement("li")
        let contenido = document.createTextNode("Numero " + (i+1))
        console.log(contenido)

        listaOl_entrada.appendChild(contenido)
        listaOl.appendChild(listaOl_entrada)
    }

    lista.appendChild(listaOl)

}